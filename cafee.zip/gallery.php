<html>
<head>
<title></title> 
<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>
<body>
 <!-- Gallery Section -->
    <section class="gallery" id="gallery">
      <h2 class="section_title">Gallery</h2>
      <div class="section_container">
        <div class="gallery_container">
          <div class="gallery_items">
            <img src="images/gallery_1.jpg" alt="Gallery Image" />
          </div>
          <div class="gallery_items">
            <img src="images/gallery_2.jpg" alt="Gallery Image" />
          </div>
          <div class="gallery_items">
            <img src="images/gallery_3.jpg" alt="Gallery Image" />
          </div>
          <div class="gallery_items">
            <img src="images/gallery_4.jpg" alt="Gallery Image" />
          </div>
          <div class="gallery_items">
            <img src="images/gallery_5.jpg" alt="Gallery Image" />
          </div>
          <div class="gallery_items">
            <img src="images/gallery_6.jpg" alt="Gallery Image" />
          </div>
        </div>
      </div>
    </section>
</body>
</html>	